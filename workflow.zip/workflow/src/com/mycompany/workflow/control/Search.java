/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.workflow.control;

import java.sql.*;

/**
 *
 * @author John Nan
 */
public class Search {

    //for Login
    public boolean exit(String name, String password) throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        //链接至数据库
        String jdbc = "jdbc:mysql://127.0.0.1:3306/workflow";
        Connection conn = DriverManager.getConnection(jdbc, "root", "crawn@420");

        Statement state = conn.createStatement();//容器
        String sql = "select * from employee where " + "password = '" + password + "' and name = '" + name+"';";           //sql语句
        ResultSet rs = state.executeQuery(sql);     //将sql语句传至数据库，返回的值为一个字符集用一个变量接收 
        try {
            if (rs.next()) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            throw e;
        } finally {
            conn.close();
        }
    }

    //for Search no paramenter
    public boolean search() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        //链接至数据库
        String jdbc = "jdbc:mysql://127.0.0.1:3306/mydb";
        Connection conn = DriverManager.getConnection(jdbc, "root", "");

        Statement state = conn.createStatement();//容器
        String sql = "select * from xs";           //sql语句
        ResultSet rs = state.executeQuery(sql);     //将sql语句传至数据库，返回的值为一个字符集用一个变量接收 

        while (rs.next()) {    //next（）获取里面的内容
            System.out.println(rs.getString(1) + " " + rs.getString(2) + " " + rs.getString(3));
                         //getString（n）获取第n列的内容
            //数据库中的列数是从1开始的
        }
        conn.close();
        return true;
    }

    //for Search no paramenter
    public boolean search(int[] pram) throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        //链接至数据库
        String jdbc = "jdbc:mysql://127.0.0.1:3306/mydb";
        Connection conn = DriverManager.getConnection(jdbc, "root", "");

        Statement state = conn.createStatement();//容器
        String sql = "select * from xs";           //sql语句
        ResultSet rs = state.executeQuery(sql);     //将sql语句传至数据库，返回的值为一个字符集用一个变量接收 

        while (rs.next()) {    //next（）获取里面的内容
            System.out.println(rs.getString(1) + " " + rs.getString(2) + " " + rs.getString(3));
                         //getString（n）获取第n列的内容
            //数据库中的列数是从1开始的
        }
        conn.close();
        return true;
    }

}
