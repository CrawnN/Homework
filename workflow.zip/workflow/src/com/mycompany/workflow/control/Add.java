/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mycompany.workflow.control;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author John Nan
 */
public class Add {
    public boolean add() throws ClassNotFoundException, SQLException{
     Class.forName("com.mysql.jdbc.Driver");//加载驱动
        
        String jdbc="jdbc:mysql://127.0.0.1:3306/mydb?characterEncoding=GBK";
        Connection conn=DriverManager.getConnection(jdbc, "root", "");//链接到数据库
        
        Statement state=conn.createStatement();   //容器
        String sql="insert into xs values('1108','张伟','汉企')";   //SQL语句
        state.executeUpdate(sql);         //将sql语句上传至数据库执行
        
        conn.close();//关闭通道
        return true;
    }
    
}
